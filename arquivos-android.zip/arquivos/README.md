# Arquivos

Gerenciador de arquivos Android, open-source (MIT), em Kotlin + Jetpack Compose + Material 3.

- Navegação por pastas, ordenação (pastas primeiro), ícones por tipo
- Criar pasta, renomear, excluir (com confirmação), abrir arquivos em outros apps
- Tema claro/escuro e cores dinâmicas (Android 12+)

## Compilar
Abra a pasta no Android Studio (ele gera o Gradle wrapper) e rode `app`.
Requer Android 11+ (API 30). Usa a permissão "Acesso a todos os arquivos".

## Decisões (Ponytail)
- Sem Hilt, Room ou Coil: só o necessário. Evoluir quando houver necessidade real.
- Validação de nome e checagem de caminho dentro do armazenamento (anti path traversal).

## Compilar sem PC (GitHub Actions)
Envie o projeto para um repositório no GitHub. Em **Actions → Build APK**, ao final da execução, baixe o artefato `arquivos-debug-apk` (APK de debug instalável).
