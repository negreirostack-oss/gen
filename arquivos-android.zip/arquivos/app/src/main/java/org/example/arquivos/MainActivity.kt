package org.example.arquivos

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = androidx.compose.foundation.isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(primary = Color(0xFF9DB7FF))
        else -> lightColorScheme(primary = Color(0xFF2457D6))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root() {
    var granted by remember { mutableStateOf(Environment.isExternalStorageManager()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = Environment.isExternalStorageManager() }
    if (granted) FilesScreen() else PermissionScreen()
}

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Filled.Folder, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text("Acesso aos arquivos", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text(
                "Para listar e gerenciar suas pastas, conceda acesso a todos os arquivos. Nada sai do aparelho.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                )
            }) { Text("Conceder acesso") }
        }
    }
}

private sealed interface Dlg
private object DlgNew : Dlg
private data class DlgRename(val f: File) : Dlg
private data class DlgDelete(val f: File) : Dlg

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(vm: FilesViewModel = viewModel()) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    fun fail() = Toast.makeText(ctx, "Não foi possível concluir a ação", Toast.LENGTH_SHORT).show()

    BackHandler(enabled = !vm.atRoot) { vm.up() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(if (vm.atRoot) "Armazenamento" else vm.dir.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            vm.dir.path,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                },
                navigationIcon = {
                    if (!vm.atRoot) IconButton(onClick = vm::up) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { dlg = DlgNew }) { Icon(Icons.Filled.CreateNewFolder, "Nova pasta") }
        },
    ) { padding ->
        if (vm.items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Pasta vazia", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(vm.items, key = { it.path }) { f ->
                    FileRow(
                        f,
                        onOpen = { if (f.isDirectory) vm.enter(f) else openFile(ctx, f) },
                        onRename = { dlg = DlgRename(f) },
                        onDelete = { dlg = DlgDelete(f) },
                    )
                }
            }
        }
    }

    when (val d = dlg) {
        DlgNew -> NameDialog("Nova pasta", "", { if (!vm.mkdir(it)) fail() }) { dlg = null }
        is DlgRename -> NameDialog("Renomear", d.f.name, { if (!vm.rename(d.f, it)) fail() }) { dlg = null }
        is DlgDelete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Excluir \"${d.f.name}\"?") },
            text = { Text(if (d.f.isDirectory) "A pasta e todo o conteúdo serão apagados." else "Esta ação não pode ser desfeita.") },
            confirmButton = {
                TextButton(onClick = { if (!vm.delete(d.f)) fail(); dlg = null }) {
                    Text("Excluir", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Cancelar") } },
        )
        null -> Unit
    }
}

@Composable
private fun FileRow(f: File, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    ListItem(
        modifier = Modifier.clickable(onClick = onOpen),
        leadingContent = {
            Surface(
                shape = CircleShape,
                color = if (f.isDirectory) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.size(44.dp),
            ) { Box(contentAlignment = Alignment.Center) { Icon(iconFor(f), null) } }
        },
        headlineContent = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(remember(f, f.lastModified()) { subtitle(f) }) },
        trailingContent = {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Mais opções") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Renomear") },
                        leadingIcon = { Icon(Icons.Filled.Edit, null) },
                        onClick = { menu = false; onRename() },
                    )
                    DropdownMenuItem(
                        text = { Text("Excluir") },
                        leadingIcon = { Icon(Icons.Filled.Delete, null) },
                        onClick = { menu = false; onDelete() },
                    )
                }
            }
        },
    )
}

@Composable
private fun NameDialog(title: String, initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Nome") }) },
        confirmButton = {
            TextButton(enabled = validName(name), onClick = { onConfirm(name.trim()); onDismiss() }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

private fun iconFor(f: File): ImageVector = if (f.isDirectory) Icons.Filled.Folder else when (f.extension.lowercase()) {
    "jpg", "jpeg", "png", "gif", "webp", "heic" -> Icons.Filled.Image
    "mp4", "mkv", "webm", "mov" -> Icons.Filled.Movie
    "mp3", "wav", "flac", "ogg", "m4a" -> Icons.Filled.AudioFile
    "pdf" -> Icons.Filled.PictureAsPdf
    "zip", "rar", "7z", "tar", "gz" -> Icons.Filled.FolderZip
    else -> Icons.Filled.InsertDriveFile
}

private fun openFile(ctx: Context, f: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        ctx.startActivity(Intent.createChooser(intent, null))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "Nenhum app para abrir este arquivo", Toast.LENGTH_SHORT).show()
    }
}
