package org.example.arquivos

import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import java.io.File
import java.text.DateFormat
import java.util.Date

// ponytail: limite listagem síncrona na thread principal; evoluir para coroutine (Dispatchers.IO)
// quando houver pastas com milhares de itens.
class FilesViewModel : ViewModel() {
    private val root: File = Environment.getExternalStorageDirectory()
    private val rootPath = root.canonicalPath

    var dir by mutableStateOf(root); private set
    var items by mutableStateOf(emptyList<File>()); private set

    val atRoot get() = dir.canonicalPath == rootPath

    init { refresh() }

    private fun inRoot(f: File): Boolean {
        val p = f.canonicalPath
        return p == rootPath || p.startsWith(rootPath + File.separator)
    }

    private fun refresh() {
        items = dir.listFiles().orEmpty()
            .filter { !it.name.startsWith(".") }
            .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }

    fun enter(f: File) {
        if (f.isDirectory && inRoot(f)) { dir = f; refresh() }
    }

    fun up() {
        if (!atRoot) { dir = dir.parentFile ?: return; refresh() }
    }

    fun mkdir(name: String) = validName(name) && File(dir, name).mkdir().also { refresh() }

    fun rename(f: File, name: String): Boolean {
        val target = File(f.parentFile, name)
        return validName(name) && inRoot(f) && !target.exists() && f.renameTo(target).also { refresh() }
    }

    fun delete(f: File) = inRoot(f) && f.canonicalPath != rootPath && f.deleteRecursively().also { refresh() }
}

fun validName(name: String) = name.isNotBlank() && '/' !in name && name != "." && name != ".."

fun humanSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = -1
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return "%.1f %s".format(v, units[i])
}

fun subtitle(f: File): String {
    val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.lastModified()))
    return if (f.isDirectory) "${f.list()?.size ?: 0} itens · $date" else "${humanSize(f.length())} · $date"
}
